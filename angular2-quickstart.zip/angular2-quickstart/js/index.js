var app = angular.module('MyApp', ['ngMaterial', 'ngMessages','material.svgAssetsCache']);

app.controller('SelectedTextController',['$scope','$http', function($scope , $http) {
  var count = 1;
  $scope.headerlist = [];
  $scope.typehead = [];
  $scope.typeheadcontent = [];
  $scope.res;
  $scope.typeurl;
  $scope.items = ['GET', 'POST', 'PUT', 'PATCH' , 'DELETE'];
  $scope.bodyforms = ['application/x-www-form-url-encoded' , 'application/json'];
  $scope.selectedItem;
  $scope.selectedForm;
  $scope.databody;
  $scope.getSelectedText = function() {
    if ($scope.selectedItem !== undefined) {
      method = $scope.selectedItem;
      return "Selecting : " + $scope.selectedItem;
    } else {
      return "Select a method";
    }
  };
  $scope.getSelectedForm = function() {
    if ($scope.selectedForm !== undefined) {
      return "Selecting : " + $scope.selectedForm;
    } else {
      return "Select a Form";
    }
  };
  $scope.request = function(){
    var json = {};
    for(var i = 0 ; i < $scope.typehead.length ;i++)
    if($scope.typehead[i] != "")
    json[$scope.typehead[i]] = $scope.typeheadcontent[i];
    if($scope.selectedForm !== undefined)
    json['Content-type'] = $scope.selectedForm;
    var body = $scope.databody;
    $http({
      method: $scope.selectedItem,
      url: $scope.typeurl,
      headers:json,
      data:body
    }).then(function successCallback(response)
    {
      $scope.res = response;
    }, function errorCallback(response)
    {
      $scope.res = response;
    })
  };
}])
.filter('trustHtml', ['$sce', function ($sce) {
  return function (text) {
    return $sce.trustAsHtml(text);
  };
}]);
app.config(function($mdThemingProvider) {
  var customBlueMap = 		$mdThemingProvider.extendPalette('light-blue', {
    'contrastDefaultColor': 'light',
    'contrastDarkColors': ['50'],
    '50': 'ffffff'
  });
});
